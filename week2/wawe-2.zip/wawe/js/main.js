$(function () {
    var mixer = mixitup('.gallery__container');
});